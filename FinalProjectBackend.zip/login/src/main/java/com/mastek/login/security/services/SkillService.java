package com.mastek.login.security.services;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mastek.login.model.Skill;
import com.mastek.login.repository.ISkillRepository;

@Service
public class SkillService {
	
	@Autowired(required = true)
	private ISkillRepository repository;
	
	public Iterable<Skill> findAll(){
		System.out.println("Skill Fetch  called from service");
		return repository.findAll();
	}
//
	public Optional<Skill> findById(int id) {
		System.out.println("Skill FindById by ID called from service");
		return repository.findById(id);
	}
//	
	public String save(Skill entity) {
		System.out.println("Skill Create called from service");
		Skill newSkill=repository.save(entity);
		return " skill saved "+newSkill;
	}
	
	public String deleteById(int skill_id) {
		System.out.println("Skill delete  called from service");
		repository.deleteById(skill_id);
		return " skill deleted"+skill_id;
	}

}

