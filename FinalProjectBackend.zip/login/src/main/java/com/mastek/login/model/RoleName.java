package com.mastek.login.model;
//enum to define roles.
public enum  RoleName {
    ROLE_USER,
    ROLE_ADMIN
}
