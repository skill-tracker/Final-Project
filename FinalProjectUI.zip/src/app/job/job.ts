export class Job {
    _id?:number;
    job_id: number;
    company_name:string;
    job_desc:string;
    job_title:string;
    job_url:string;
    searchJob:string;
    _v?:number;
}