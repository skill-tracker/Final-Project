import { Component, OnInit } from '@angular/core';

import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UserService } from 'src/app/services/user.service';
import { Job } from '../job';

@Component({
  selector: 'app-job-add',
  templateUrl: './job-add.component.html',
  styleUrls: ['./job-add.component.css']
})
export class JobAddComponent implements OnInit {
  submitted=false;
  angForm:FormGroup;
  job:Job=new Job();
  constructor(private fb: FormBuilder , private service:UserService) { this.createForm();}

  ngOnInit() {
  }
  createForm(){
    this.angForm=this.fb.group({
      job_id:['',Validators.required],
      company_name:['',Validators.required],
      job_desc:['',Validators.required],
      job_title:['',Validators.required],
      job_url:['',Validators.required],
    });
  }
 
  newJob():void{

    this.submitted=false;
    this.job = new Job();
  }

  save(){
    this.service.addJobBoard(this.job)
    .subscribe(data=>console.log(data),error=>console.log(error));
    this.job=new Job();
   
  }
  
  onSubmit(){
 
    this.submitted = true;
    this.save();
  }
  
}


