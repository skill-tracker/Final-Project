import { PipeTransform, Pipe } from '@angular/core';




@Pipe({
    name: 'CourseFilter'
})
export class CourseFilter implements PipeTransform {
    transform(courses:any, searchCourse: string):any {
        if (!courses || !searchCourse) {
            return courses;
        }

        return courses.filter(course =>
            course.course_name.toLowerCase().indexOf(searchCourse.toLowerCase()) !== -1);
    }
}