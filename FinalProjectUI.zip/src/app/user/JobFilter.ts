import { PipeTransform, Pipe } from '@angular/core';




@Pipe({
    name: 'JobFilter'
})
export class JobFilter implements PipeTransform {
    transform(jobs:any, searchJob: string):any {
        if (!jobs || !searchJob) {
            return jobs;
        }

        return jobs.filter(job =>
            job.job_title.toLowerCase().indexOf(searchJob.toLowerCase()) !== -1);
    }
}