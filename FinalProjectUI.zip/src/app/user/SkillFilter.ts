import { PipeTransform, Pipe } from '@angular/core';

import { Skill } from '../skill/skill';


@Pipe({
    name: 'SkillFilter'
})
export class SkillFilter implements PipeTransform {
    transform(skills:any, searchSkill: string):any {
        if (!skills || !searchSkill) {
            return skills;
        }

        return skills.filter(skill =>
            skill.skill_name.toLowerCase().indexOf(searchSkill.toLowerCase()) !== -1);
    }
}