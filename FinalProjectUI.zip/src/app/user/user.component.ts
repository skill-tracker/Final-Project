import { Component, OnInit } from '@angular/core';
import { UserService } from '../services/user.service';





@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
  board: Object;
  jobBoard: Object;
  courseBoard: Object;
  skillBoard: Object;
  errorMessage: string;

  constructor(private userService: UserService) { }

  ngOnInit() {
    
    this.userService.getSkillBoard1().subscribe(
      data => {
        this.skillBoard = data;
      },
      error => {
        this.errorMessage = `${error.status}: ${JSON.parse(error.error).message}`;
      }     
    );

    this.userService.getCourseBoard1().subscribe(
      data => {
        this.courseBoard = data;
      },
      error => {
        this.errorMessage = `${error.status}: ${JSON.parse(error.error).message}`;
      }     
    );
    

    this.userService.getJobBoard1().subscribe(
      data => {
        this.jobBoard = data;
      },
      error => {
        this.errorMessage = `${error.status}: ${JSON.parse(error.error).message}`;
      }     
    );
    
    
    

  }
  
    

   
}
