import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { UserService } from 'src/app/services/user.service';
import { Course } from '../course';


@Component({
  selector: 'app-course-add',
  templateUrl: './course-add.component.html',
  styleUrls: ['./course-add.component.css']
})
export class CourseAddComponent implements OnInit {
  submitted=false;
  angForm:FormGroup;
  course:Course=new Course();
  constructor(private fb: FormBuilder , private userService:UserService) { this.createForm();}

  ngOnInit() {
  }
  createForm(){
    this.angForm=this.fb.group({
      course_id :['',Validators.required],
      course_name:['',Validators.required],
      description:['',Validators.required],
      link:['',Validators.required],
      
    });
  }
 

  newCourse() : void {
    this.submitted=false;
    this.course=new Course();
  }

  save() {

    this.userService.addCourseBoard(this.course)
    .subscribe(data=>console.log(data),error=>console.log(error));
    this.course=new Course();
  }

  onSubmit() {

    this.submitted=true;
    this.save();

  }




}