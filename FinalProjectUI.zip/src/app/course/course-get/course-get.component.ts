import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/services/user.service';
import { Course } from '../course';

@Component({
  selector: 'app-course-get',
  templateUrl: './course-get.component.html',
  styleUrls: ['./course-get.component.css']
})
export class CourseGetComponent implements OnInit {

  board:Object;
  errorMessage: string;
  selectedCourse:Course;

  constructor(private userService : UserService) { }

  ngOnInit() {
    this.userService.getCourseBoard().subscribe(
      data => {
        this.board = data;
      },
      error => {
        this.errorMessage = `${error.status}: ${JSON.parse(error.error).message}`;
      }



    );
}
onSelection(course:Course){
  this.selectedCourse=course;
}
deleteCourse(course_id: any) {
  this.userService.deleteCourse(course_id)
    .subscribe(
      data => {
        console.log(data);
        
      },
      error => console.log(error));
}
}
