import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SkillGetComponent } from './skill-get.component';

describe('SkillGetComponent', () => {
  let component: SkillGetComponent;
  let fixture: ComponentFixture<SkillGetComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SkillGetComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SkillGetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
