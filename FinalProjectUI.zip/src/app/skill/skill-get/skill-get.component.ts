import { Component, OnInit } from '@angular/core';
import { Skill } from '../skill';
import { ActivatedRoute } from '@angular/router'
import { Observable } from 'rxjs';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-skill-get',
  templateUrl: './skill-get.component.html',
  styleUrls: ['./skill-get.component.css']
})
export class SkillGetComponent implements OnInit {

  board: Object;
  errorMessage: string;
  job:Skill;
  selectedSkill:Skill;

  constructor(private userService: UserService) { }

  ngOnInit() {
    this.userService.getSkillBoard().subscribe(
      data => {
        this.board = data;
      },
      error => {
        this.errorMessage = `${error.status}: ${JSON.parse(error.error).message}`;
      }
    );
  }
  onSelection(skill:Skill){
    this.selectedSkill=skill;
  }
  deleteSkill(skill_id: any) {
    this.userService.deleteSkill(skill_id)
      .subscribe(
        data => {
          console.log(data);
          // this.reloadData();
        },
        error => console.log(error));
  }
  

}
