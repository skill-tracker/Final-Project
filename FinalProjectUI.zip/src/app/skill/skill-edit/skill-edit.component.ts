import { Component, OnInit } from '@angular/core';
import { Skill } from '../skill';
import { UserService } from 'src/app/services/user.service';
@Component({
  selector: 'app-skill-edit',
  templateUrl: './skill-edit.component.html',
  styleUrls: ['./skill-edit.component.css']
})
export class SkillEditComponent implements OnInit {
  skill:Skill=new Skill();
  board:Object;
  errorMessage:string;
    constructor(private service:UserService) { }
  ngOnInit() {
    this.service.getSkillBoard().subscribe(
        data => {
          this.board = data;
        },
        error => {
          this.errorMessage = `${error.status}: ${JSON.parse(error.error).message}`;
        }
      );
  }
  updateSkill(priority:number){
   console.log("Skill is getting edited");
   this.service.updateSkill(this.skill.skill_id,{priority:priority}).subscribe(
     data=>{
       console.log(data);
       this.skill=data as Skill;
     },
     error=>console.log(error));
  }
  
}
