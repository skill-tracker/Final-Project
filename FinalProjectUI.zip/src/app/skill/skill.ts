export class Skill{               
    skill_id:number;
    skill_name:string;
    priority:number;     
    searchSkill:string;         
}